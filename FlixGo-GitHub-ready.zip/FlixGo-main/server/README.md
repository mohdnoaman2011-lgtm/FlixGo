# FlixGo Server

Requires: Node 18+, yt-dlp, ffmpeg.

    node server.js                      # runs on :8787
    docker build -t flixgo-server . && docker run -p 8787:8787 flixgo-server

Env vars: PORT, PUBLIC_URL (public https address, required behind a proxy), MAX_JOBS, FILES_DIR, YTDLP_BIN.

API: POST /api/download {url, quality, audioOnly} -> {downloadUrl, fileName}
Files are deleted after 30 minutes. Keep yt-dlp updated: `yt-dlp -U`.
