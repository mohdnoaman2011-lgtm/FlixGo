# تشغيل FlixGo على GitHub حتى الحصول على APK

هذا المشروع يتكون من جزأين:

1. **تطبيق Flutter/Android** داخل مجلد المشروع الرئيسي.
2. **خادم Node.js** داخل `server/`، وهو الذي يشغّل `yt-dlp` و`ffmpeg` وينفذ التنزيلات.

> مهم: GitHub Actions يبني ملف APK فقط. لا يصلح GitHub Pages لتشغيل خادم Node.js دائم. يجب نشر مجلد `server` على خدمة تدعم Docker أو Node.js، ثم وضع رابط الخادم في عملية بناء التطبيق.

## 1. المتطلبات

- حساب GitHub.
- مستودع GitHub جديد، ويفضل أن يكون Public إذا كنت تريد استخدام GitHub Actions دون تعقيدات الحصة.
- رابط HTTPS عام لخادم FlixGo، مثل:
  `https://flixgo-api.example.com`
- عدم وضع كلمات مرور أو مفاتيح سرية داخل الملفات أو GitHub.

## 2. إنشاء مستودع GitHub

1. افتح: <https://github.com/new>
2. اكتب اسمًا مثل `FlixGo`.
3. اختر **Public** أو **Private**.
4. لا تفعل خيار إضافة README أو `.gitignore` لأن المشروع يحتوي عليهما بالفعل.
5. اضغط **Create repository**.

## 3. رفع المشروع من جهازك

بعد فك ضغط `FlixGo.zip`، افتح Terminal داخل المجلد الذي يحتوي على:

```text
pubspec.yaml
lib/
android/
server/
.github/
```

نفذ الأوامر التالية، مع استبدال `YOUR_USERNAME` باسم حسابك:

```bash
git init
git branch -M main
git add .
git commit -m "Initial FlixGo project"
git remote add origin https://github.com/YOUR_USERNAME/FlixGo.git
git push -u origin main
```

إذا طلب GitHub تسجيل الدخول، استخدم GitHub CLI أو Personal Access Token بدل كلمة مرور الحساب.

بعد الرفع، تأكد من وجود هذه الملفات في GitHub:

```text
.github/workflows/main.yml
pubspec.yaml
lib/main.dart
android/
server/
```

ولا ترفع `android/local.properties` أو ملفات `.env`؛ فهي ملفات محلية أو قد تحتوي على إعدادات حساسة.

## 4. نشر خادم FlixGo

المجلد `server` يحتاج إلى:

- Node.js 18 أو أحدث.
- `yt-dlp`.
- `ffmpeg`.
- منفذ يستلمه المتغير `PORT`.
- رابط HTTPS عام إذا كان التطبيق على هاتف حقيقي.

يوجد Dockerfile جاهز داخل `server/`. في أي خدمة Docker، اجعل **Root Directory** هو `server`، ثم استخدم:

```bash
docker build -t flixgo-server ./server
docker run -p 8787:8787 flixgo-server
```

عند النشر على خدمة سحابية، لا تفترض أن المنفذ الخارجي هو 8787؛ اترك الخدمة تمرر قيمة `PORT`، والكود يقرأها تلقائيًا.

بعد النشر اختبر:

```bash
curl https://YOUR_SERVER_DOMAIN/health
```

يجب أن تحصل على:

```json
{"ok":true}
```

إذا كان الخادم خلف Proxy، اضبط متغير البيئة:

```text
PUBLIC_URL=https://YOUR_SERVER_DOMAIN
```

ويجب أن يكون الرابط بدون `/` في نهايته. لا تستخدم رابط `http://localhost` أو رابطًا داخليًا.

> استخدم الخادم لتنزيل المحتوى الذي تملك حق تنزيله أو الذي يسمح صاحبه بذلك، والتزم بشروط المنصات والقوانين المحلية.

## 5. تشغيل GitHub Actions وبناء APK

تم تعديل Workflow ليطلب رابط الخادم عند بدء البناء.

1. افتح تبويب **Actions** في المستودع.
2. اختر **Build FlixGo APK** من القائمة اليسرى.
3. اضغط **Run workflow**.
4. في الحقل `api_base_url` ضع رابط الخادم HTTPS، مثال:

   ```text
   https://flixgo-api.example.com
   ```

5. اترك إصدار Flutter الافتراضي كما هو. إذا ظهر أن الإصدار غير موجود، اختر إصدارًا متاحًا من قناة Flutter stable.
6. اضغط **Run workflow**.
7. افتح عملية البناء وانتظر انتهاء الخطوات:
   - Checkout
   - Setup Java
   - Setup Flutter
   - Get dependencies
   - Analyze Dart code
   - Build release APK
   - Upload APK artifact
8. بعد نجاح العملية، انزل إلى قسم **Artifacts** واضغط:
   `flixgo-release-apk`
9. فك ضغط الملف الناتج، وستجد:

   ```text
   app-release.apk
   ```

## 6. تثبيت APK على هاتف Android

### الطريقة الأولى: من GitHub

انقل `app-release.apk` إلى الهاتف، افتحه، واسمح بالتثبيت من المصدر الذي استخدمته عند فتح الملف.

### الطريقة الثانية: باستخدام ADB

فعّل **Developer options** و**USB debugging**، ثم نفذ:

```bash
adb install -r app-release.apk
```

## 7. اختبار التطبيق

1. افتح التطبيق.
2. الصق رابطًا مدعومًا.
3. اختر Video أو Audio.
4. اختر الجودة.
5. اضغط Start download.
6. إذا فشل التحميل، اختبر أولًا:

```bash
curl https://YOUR_SERVER_DOMAIN/health
```

ثم راجع سجلات الخادم. أكثر الأسباب شيوعًا:

- رابط API غير صحيح.
- استخدام `http` بدل `https` على هاتف حقيقي.
- الخادم غير منشور أو نائم.
- `yt-dlp` أو `ffmpeg` غير مثبتين.
- المنصة غيّرت طريقة الوصول إلى الرابط.
- الخدمة السحابية أغلقت الاتصال بسبب طول مدة التنزيل.

## 8. فرق الرابط حسب نوع الجهاز

القيمة الافتراضية في التطبيق هي:

```text
http://10.0.2.2:8787
```

وهذه تعمل فقط مع **Android Emulator** عندما يكون الخادم يعمل على جهاز التطوير نفسه.

- Android Emulator + خادم محلي: `http://10.0.2.2:8787`
- هاتف حقيقي + خادم محلي: استخدم عنوان IP لجهازك على الشبكة، مع إعدادات الشبكة المناسبة.
- APK منشور للمستخدمين: استخدم رابط HTTPS عام للخادم، وهو الخيار الصحيح للإصدار النهائي.

## 9. تحديث التطبيق لاحقًا

بعد تعديل الكود:

```bash
git add .
git commit -m "Update FlixGo"
git push
```

ثم شغّل Workflow مرة أخرى من **Actions > Build FlixGo APK > Run workflow**.

## 10. أخطاء شائعة في GitHub Actions

### Flutter version not found

افتح Workflow وعدل قيمة `flutter_version` إلى إصدار متاح من Flutter stable، ثم أعد التشغيل.

### `flutter analyze` يفشل

شغّل محليًا:

```bash
flutter pub get
flutter analyze
```

ثم أصلح الأخطاء الظاهرة وادفع التعديل إلى GitHub.

### `Output file not found`

تأكد أن الأمر هو:

```bash
flutter build apk --release
```

وأن مسار Artifact هو:

```text
build/app/outputs/flutter-apk/app-release.apk
```

### التطبيق يفتح لكن التنزيل يفشل

هذا يعني غالبًا أن APK بُني بنجاح، لكن رابط `FLIXGO_API_BASE_URL` غير صحيح أو أن خادم Node لا يعمل. أعد بناء APK مع رابط HTTPS صحيح، ثم اختبر endpoint `/health`.

## النتيجة المتوقعة

المسار الكامل هو:

```text
GitHub Repository
        |
        +--> GitHub Actions --> app-release.apk
        |
        +--> server/ منشور على خدمة Node/Docker
                              |
                              +--> /health
                              +--> /api/download
```
